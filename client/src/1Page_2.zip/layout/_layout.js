import styled from 'styled-components';

const OneLayout = () => {
    return(
        <>
            <Allwrap>
                
            </Allwrap>
        </>
    )
}
export default OneLayout;

const Allwrap = styled.div`
    width: 1920px;
    height: 1080px;
`